package CircLinkedList;

/**
 *
 * @author mirna_farahat
 */
public class CircLinkedList {
   
    private Node current;
    private Node curr;
    private int size;
   
    public CircLinkedList(){
        this.size = 0;
    }
   
   
    private class Node {
        private int value;
        private Node next;
       
        public Node(int value){
            this.value = value;
        }
    }
   
   
    public void insert(int val){
        Node node = new Node(val);
        node.next = current;
        current = node;
       
        if(curr == null){
            curr = current;
           
        }
        size += 1;
       
    }
    public void insertLast(int val){
        if(curr == null){
            insert(val);
            return;
        }
        Node node = new Node(val);
        curr.next = node;
        curr = node;
        size++;
    }
   
    public void insert(int val, int index){
        if(index == 0){
            insert(val);
            return;
        }
        if (index == size){
            insert(val);
            return;
           
        }
        Node temp = current;
        for (int i = 1; i < index; i++){
            temp = temp.next;
        }
       
        Node node = new Node(val);
        temp.next = node;
       
        size++;

    }
    public int deletelast(){
        if (size <= 1){
            return delete();
        }
        Node secondlast = get(size -2);
        int val = curr.value;
       
        curr = secondlast;
        curr.next = null;
       
        return val;
    }
   
    public Node get(int index){
        Node node = current;
        for(int i = 0; i < index; i++){
            node = node.next;
        }
        return node;
    }
   
    public int delete(){
        int val = current.value;
        current = current.next;
        if(current == null){
            curr = null;

        }
        return size--;
    }
   
    public void display(){
        Node temp = current;
        while(temp != null){
            System.out.println(temp.value);
            temp = temp.next;
        }
       
    }
   
}

