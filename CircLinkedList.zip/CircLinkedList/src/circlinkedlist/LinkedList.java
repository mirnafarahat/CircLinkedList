
package CircLinkedList;
/**
 *
 * @mirna_farahat
 */
public class LinkedList {

    public static void main(String[] args) {
       CircLinkedList list = new CircLinkedList();
       list.insert(68);
       list.insert(20);
       list.insert(44);
       list.insert(12);
       list.insertLast(92);
       list.insert(100, 3);
       list.display();
       System.out.println(list.delete());
       list.display();
       System.out.println(list.deletelast());
       list.display();
       
    }
   
}

